<?php include 'header.php';?>
<!-- banner -->
<div class="inside-banner">
  <div class="container"> 
    <span class="pull-right"><a href="./">Accueil</a> / À propos</span>
    <h2>À propos</h2>
</div>
</div>
<!-- banner -->


<div class="container">
<div class="spacer">
<div class="row">
  <div class="col-lg-8  col-lg-offset-2">
  <img src="images/about.jpg" class="img-responsive thumbnail"  alt="realestate">
  <h3>Local Idéal</h3>
  <p>Depuis 1913, LocaFacile façonne l’industrie en aidant les gens de partout au pays à trouver leur propriété idéal et en appuyant la communauté.</p>
  <p>En plus d’être une activité commerciale, Trouver ce que vous aime est aussi pour nous une réelle passion. C’est pourquoi nous faisons de nos meilleurs pour vous et votre famille puisse trouver un endroit d'appartenace. Votre satisfaction nous importe!!</p>
  
  </div>
 
</div>
</div>
</div>

<?php include'footer.php';?>